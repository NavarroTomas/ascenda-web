import { useEffect, useState } from 'react'
import RichTextEditor from './RichTextEditor.jsx'
import { decryptNote, encryptNote } from '../lib/noteCrypto.js'
import { useFormDraft } from '../lib/formDrafts.js'
import DraftRecoveryNotice from './DraftRecoveryNotice.jsx'

const EMPTY = { title: '', content_html: '', color: '#38d9c6', is_pinned: false, is_archived: false, is_locked: false, category_id: '' }
function normalizeNote(note) { return { ...EMPTY, ...(note || {}), category_id: note?.category_id || '', content_html: note?.is_locked ? '' : note?.content_html || '' } }

export default function NoteModal({ open, note, categories, onClose, onSave, onConvertTask, onConvertReminder }) {
  const [form,setForm]=useState(EMPTY); const [pin,setPin]=useState(''); const [unlockPin,setUnlockPin]=useState(''); const [unlocked,setUnlocked]=useState(false); const [saving,setSaving]=useState(false); const [error,setError]=useState('')
  const draftEnabled = !note?.is_locked && !form.is_locked
  const draft = useFormDraft({ open, type: 'note', entityId: note?.id || 'new', form, setForm, getInitialForm: () => normalizeNote(note), enabled: draftEnabled })
  useEffect(() => { if (!open) return; setPin(''); setUnlockPin(''); setUnlocked(!note?.is_locked); setError('') }, [open, note])

  if(!open)return null
  const update=(k,v)=>setForm(c=>({...c,[k]:v}))
  async function unlock(){ try { const plain=await decryptNote(note,unlockPin); update('content_html',plain); setUnlocked(true); setError('') } catch(e){setError(e.message)} }
  async function submit(e){ e.preventDefault(); setSaving(true); setError(''); try { let payload={ ...form, title: form.title.trim() || 'Nueva nota', category_id: form.category_id || null }; if(form.is_locked){ const activePin=pin || unlockPin; const encrypted=await encryptNote(form.content_html,activePin); payload={...payload,...encrypted,content_html:null} } else { payload={...payload,encrypted_content:null,encryption_iv:null,encryption_salt:null} } const ok=await onSave(payload,note); if(ok){draft.clearDraft();onClose()} } catch(e){setError(e.message)} finally{setSaving(false)} }
  if(note?.is_locked&&!unlocked)return <div className="modal-backdrop"><section className="editor-modal panel enter-up locked-note-gate"><div className="modal-heading"><div><p className="eyebrow">NOTA BLOQUEADA</p><h2>{note.title}</h2></div><button className="icon-button" type="button" onClick={onClose}>×</button></div><p>Ingresá el PIN. El contenido se descifra únicamente en este navegador.</p><input type="password" autoFocus value={unlockPin} onChange={(e)=>setUnlockPin(e.target.value)} placeholder="PIN de la nota" />{error&&<span className="form-error">{error}</span>}<div className="modal-actions"><button className="ghost-button" type="button" onClick={onClose}>Cancelar</button><button className="primary-button" type="button" onClick={unlock}>Desbloquear</button></div></section></div>
  return <div className="modal-backdrop" onMouseDown={(e)=>e.target===e.currentTarget&&onClose()}><form className="editor-modal panel enter-up wide-modal" onSubmit={submit}>
    <div className="modal-heading"><div><p className="eyebrow">NOTAS</p><h2>{note?'Editar nota':'Nueva nota'}</h2></div><button className="icon-button" type="button" onClick={onClose}>×</button></div>
    <DraftRecoveryNotice draft={draft.recoveredDraft} onDiscard={draft.discardDraft} />
    <label><span>Título</span><input required value={form.title} onChange={(e)=>update('title',e.target.value)} /></label>
    <RichTextEditor value={form.content_html} onAutosave={async(html)=>update('content_html',html)} onConvertTask={onConvertTask} onConvertReminder={onConvertReminder} />
    <div className="form-grid two-columns"><label><span>Categoría</span><select value={form.category_id} onChange={(e)=>update('category_id',e.target.value)}><option value="">Sin categoría</option>{categories.filter(c=>c.id).map(c=><option value={c.id} key={c.id}>{c.icon} {c.name}</option>)}</select></label><label><span>Color</span><input type="color" value={form.color} onChange={(e)=>update('color',e.target.value)} /></label></div>
    <div className="setting-list"><label className="setting-row"><span><strong>Fijar nota</strong></span><input type="checkbox" checked={form.is_pinned} onChange={(e)=>update('is_pinned',e.target.checked)} /></label><label className="setting-row"><span><strong>Archivar</strong></span><input type="checkbox" checked={form.is_archived} onChange={(e)=>update('is_archived',e.target.checked)} /></label><label className="setting-row"><span><strong>Bloquear con PIN</strong><small>El contenido se cifra. Los borradores locales se eliminan al activar el bloqueo.</small></span><input type="checkbox" checked={form.is_locked} onChange={(e)=>update('is_locked',e.target.checked)} /></label></div>
    {form.is_locked&&<label><span>{note?.is_locked?'Nuevo PIN opcional':'PIN de al menos 4 caracteres'}</span><input type="password" value={pin} onChange={(e)=>setPin(e.target.value)} placeholder={note?.is_locked?'Dejalo vacío para conservar el PIN actual':'Ingresá un PIN'} /></label>}
    {error&&<span className="form-error">{error}</span>}<div className="modal-actions"><button className="ghost-button" type="button" onClick={onClose}>Cancelar</button><button className="primary-button" disabled={saving}>{saving?'Guardando…':'Guardar nota'}</button></div>
  </form></div>
}
